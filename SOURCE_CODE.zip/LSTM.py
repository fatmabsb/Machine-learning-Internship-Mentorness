import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

# Load the dataset with correct delimiter
file_path = '/Users/fatmazohra/Desktop/everything inside/Machine Learning Internship/Task 2_Market Price Prediction/MarketPricePrediction.csv'
df = pd.read_csv(file_path, delimiter=';')

# Convert 'date' column to datetime
df['date'] = pd.to_datetime(df['date'], errors='coerce')  # 'coerce' will handle invalid dates by converting them to NaT

# Drop rows with NaT (invalid dates)
df = df.dropna(subset=['date'])

# Ensure 'date' is datetime and set as index
df.set_index('date', inplace=True)

# Scale the data
scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(df['quantity'].values.reshape(-1, 1))

# Split the data into training and testing sets (80% train, 20% test)
train_size = int(len(scaled_data) * 0.8)
train_data, test_data = scaled_data[:train_size], scaled_data[train_size:]

# Prepare the data for LSTM
def create_dataset(data, time_step=1):
    X, y = [], []
    for i in range(len(data) - time_step - 1):
        X.append(data[i:(i + time_step), 0])
        y.append(data[i + time_step, 0])
    return np.array(X), np.array(y)

time_step = 10
X_train, y_train = create_dataset(train_data, time_step)
X_test, y_test = create_dataset(test_data, time_step)

# Reshape the input to be [samples, time steps, features] which is required for LSTM
X_train = X_train.reshape(X_train.shape[0], X_train.shape[1], 1)
X_test = X_test.reshape(X_test.shape[0], X_test.shape[1], 1)

# Create the LSTM model
model = Sequential()
model.add(LSTM(50, return_sequences=True, input_shape=(time_step, 1)))
model.add(LSTM(50, return_sequences=False))
model.add(Dense(25))
model.add(Dense(1))

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

# Train the model
model.fit(X_train, y_train, batch_size=1, epochs=1)

# Forecast using the LSTM model
train_predict = model.predict(X_train)
test_predict = model.predict(X_test)

# Inverse transform to get actual values
train_predict = scaler.inverse_transform(train_predict)
test_predict = scaler.inverse_transform(test_predict)

# Calculate Mean Squared Error (MSE)
mse = mean_squared_error(test_data[time_step + 1:], test_predict)
print("Mean Squared Error (MSE):", mse)

# Plot the actual vs. forecasted values
train_plot = np.empty_like(scaled_data)
train_plot[:, :] = np.nan
train_plot[time_step:len(train_predict) + time_step, :] = train_predict

test_plot = np.empty_like(scaled_data)
test_plot[:, :] = np.nan
test_plot[len(train_predict) + (time_step * 2) + 1:len(scaled_data) - 1, :] = test_predict

plt.figure(figsize=(12, 6))
plt.plot(scaler.inverse_transform(scaled_data), label='Actual Data')
plt.plot(train_plot, label='Training Data')
plt.plot(test_plot, label='Forecasted Data', color='red')
plt.title('LSTM Model - Actual vs. Forecasted')
plt.xlabel('Date')
plt.ylabel('Quantity')
plt.legend()
plt.show()
