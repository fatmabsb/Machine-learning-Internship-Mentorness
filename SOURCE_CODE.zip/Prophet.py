from prophet import Prophet
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
# Load the dataset with correct delimiter
file_path = '/Users/fatmazohra/Desktop/everything inside/Machine Learning Internship/Task 2_Market Price Prediction/MarketPricePrediction.csv'
df = pd.read_csv(file_path, delimiter=';')
# Convert 'date' column to datetime
df['date'] = pd.to_datetime(df['date'], errors='coerce') 
 # 'coerce' will handle invalid dates by converting them to NaT
# Drop rows with NaT (invalid dates)
df = df.dropna(subset=['date'])
# Prepare the data for Prophet
df_prophet = df[['date', 'quantity']].reset_index(drop=True)
df_prophet.columns = ['ds', 'y']
# Split the data into training and testing sets (80% train, 20% test)
train_size = int(len(df_prophet) * 0.8)
train, test = df_prophet[:train_size], df_prophet[train_size:]
# Initialize and fit the Prophet model
model = Prophet()
model.fit(train)
# Forecast using the Prophet model
future = model.make_future_dataframe(periods=len(test), freq='MS')  # Change 'M' to 'MS' for Month Start
forecast = model.predict(future)
# Calculate Mean Squared Error (MSE)
test_forecast = forecast[-len(test):]['yhat']
mse = mean_squared_error(test['y'], test_forecast)
print("Mean Squared Error (MSE):", mse)
# Plot the actual vs. forecasted values
plt.figure(figsize=(12, 6))
plt.plot(train['ds'], train['y'], label='Training Data')
plt.plot(test['ds'], test['y'], label='Test Data')
plt.plot(forecast['ds'], forecast['yhat'], label='Forecast', color='red')
plt.title('Prophet Model - Actual vs. Forecasted')
plt.xlabel('Date')
plt.ylabel('Quantity')
plt.legend()
plt.show()
