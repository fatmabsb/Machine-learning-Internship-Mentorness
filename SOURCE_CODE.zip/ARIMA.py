import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

# Load the dataset with correct delimiter
file_path = '/Users/fatmazohra/Desktop/everything inside/Machine Learning Internship/Task 2_Market Price Prediction/MarketPricePrediction.csv'
df = pd.read_csv(file_path, delimiter=';')

# Inspect the first few rows of the date column to understand its format
print(df['date'].head())

# Convert 'date' column to datetime, forcing any errors to NaT
df['date'] = pd.to_datetime(df['date'], errors='coerce')

# Drop rows where 'date' could not be converted
df.dropna(subset=['date'], inplace=True)

# Ensure 'date' column is set as index
df.set_index('date', inplace=True)

# Split the data into training and testing sets (80% train, 20% test)
train_size = int(len(df) * 0.8)
train, test = df[:train_size], df[train_size:]

# Display the first few rows of the training and testing sets
print("Training set:")
print(train.head())
print("Testing set:")
print(test.head())

# Define the ARIMA model parameters (p, d, q)
p = 5  # Autoregressive order
d = 1  # Degree of differencing
q = 0  # Moving average order

# Initialize and fit the ARIMA model
model = ARIMA(train['quantity'], order=(p, d, q))
arima_model = model.fit()

# Print the model summary
print(arima_model.summary())

# Forecast using the ARIMA model
forecast = arima_model.forecast(steps=len(test))

# Calculate Mean Squared Error (MSE)
mse = mean_squared_error(test['quantity'], forecast)
print("Mean Squared Error (MSE):", mse)

# Plot the actual vs. forecasted values
plt.figure(figsize=(12, 6))
plt.plot(train.index, train['quantity'], label='Training Data')
plt.plot(test.index, test['quantity'], label='Test Data')
plt.plot(test.index, forecast, label='Forecast', color='red')
plt.title('ARIMA Model - Actual vs. Forecasted')
plt.xlabel('Date')
plt.ylabel('Quantity')
plt.legend()
plt.show()
